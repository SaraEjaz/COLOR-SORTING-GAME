#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>

using namespace std;

const int MAX_SIZE = 15;
const int STACK_SIZE = 5;

void displayInstructions(int level) {
    if (level == 1) {
        cout << "\n+*0.+-------FIRST LEVEL RULES-------+*0.+\n" << endl;
        cout << "-> There are three types of colors to sort!" << endl;
        cout << "-> There will be three stacks available!" << endl;
        cout << "-> There are limited moves!" << endl;
        cout << "-> After every move, 10 points will be rewarded!" << endl;
        cout << "-> Each stack has the capacity of 5 colors" << endl;
    } else if (level == 2) {
        cout << "\n+*0.+-------SECOND LEVEL RULES--------+*0.+\n" << endl;
        cout << "-> There are three types of colors to sort!" << endl;
        cout << "-> There will be three stacks and a power stack available!" << endl;
        cout << "-> Each stack has the capacity of 5 colors" << endl;
        cout << "-> There are limited moves!" << endl;
        cout << "-> After every move, 10 points will be rewarded!" << endl;
        cout << "-> When a stack is full, the power stack will be utilized, but 15 points will be deducted!" << endl;
    } else {
        cout << "\n+*0.+-------THIRD LEVEL RULES--------+*0.+\n" << endl;
        cout << "-> There are three types of colors to sort!" << endl;
        cout << "-> There will be three queues available!" << endl;
        cout << "-> There are limited moves!" << endl;
        cout << "-> After every move, 10 points will be rewarded!" << endl;
         cout << "-> Foe each invalid move, 2 points will be deducted!" << endl;
    }
}

void displayList(const char elements[], int size, int topIndex) {
    cout << "\nList of Elements to Sort: ";
    for (int i = 0; i < size; ++i) {
        if (i == topIndex) {
            cout << "(" << elements[i] << ") ";
        } else {
            cout << elements[i] << " ";
        }
    }
    cout << endl;
}

void displayStack(const char stack[], int top, const char* stackName) {
    cout << stackName << " Stack: ";
    if (top == -1) {
        cout << "Empty";
    } else {
        for (int i = top; i >= 0; --i) {
            cout << stack[i] << " ";
        }
    }
    cout << endl;
}

char getColorToSort(const char elements[], int topIndex) {
    return elements[topIndex];
}

bool isGameWon(const char redStack[], const char greenStack[], const char blueStack[], int chosenLevel) {
    bool isRedSorted = true;
    bool isGreenSorted = true;
    bool isBlueSorted = true;

    for (int i = 0; i < STACK_SIZE - 1; ++i) {
        if (redStack[i] != 'R' || redStack[i] > redStack[i + 1]) {
            isRedSorted = false;
            break;
        }
    }

    
    for (int i = 0; i < STACK_SIZE - 1; ++i) {
        if (greenStack[i] != 'G' || greenStack[i] > greenStack[i + 1]) {
            isGreenSorted = false;
            break;
        }
    }

    for (int i = 0; i < STACK_SIZE - 1; ++i) {
        if (blueStack[i] != 'B' || blueStack[i] > blueStack[i + 1]) {
            isBlueSorted = false;
            break;
        }
    }
    return isRedSorted && isGreenSorted && isBlueSorted;
}

unsigned int generateRandomSeed() {
    return static_cast<unsigned int>(time(nullptr));
}

int myRandom(unsigned int& seed, int min, int max) {
    seed = seed * 1103515245 + 12345;
    return static_cast<int>((seed / 65536) % (max - min + 1)) + min;
}

void initializeElements(char elements[], unsigned int& seed, int chosenLevel) {
    if (chosenLevel == 1) {
        for (int i = 0; i < MAX_SIZE; i++) {
            elements[i] = (i % 3 == 0) ? 'R' : ((i % 3 == 1) ? 'G' : 'B');
        }
    } else if (chosenLevel == 2) {
        for (int i = 0; i < MAX_SIZE; i++) {
            elements[i] = myRandom(seed, 0, 2) == 0 ? 'R' : (myRandom(seed, 0, 1) == 1 ? 'G' : 'B');
        }
    }
}

void handleFullStack(char colorToSort, char powerStack[], int& powerTop, int& score, int chosenLevel) {
    if (chosenLevel == 2) {
        cout << "\t\t\t\t\t" << colorToSort << "\n-----Stack Full! Using Power Stack.-----" << endl;
        if (powerTop < STACK_SIZE - 1) {
            powerStack[++powerTop] = colorToSort;
            score -= 15;
        } else {
            cout << "\t\t\t\t\t\n-----Power Stack Full! Cannot use it now.-----" << endl;
        }
    }
}

void push(char stack[], int& top, char color) {
    if (top < STACK_SIZE - 1) {
        stack[++top] = color;
    } else {
        cout << "\n-----Stack is full!-----" << endl;
    }
}

char pop(char stack[], int& top) {
    if (top >= 0) {
        return stack[top--];
    } else {
        cout << "\n-----Stack is empty!-----" << endl;
        return '\0';
    }
}

void playGame(int chosenLevel) {
    unsigned int seed = generateRandomSeed();
    char elements[MAX_SIZE];
    initializeElements(elements, seed, chosenLevel);

    char redStack[STACK_SIZE] = { ' ' };
    int redTop = -1;

    char greenStack[STACK_SIZE] = { ' ' };
    int greenTop = -1;

    char blueStack[STACK_SIZE] = { ' ' };
    int blueTop = -1;

    char powerStack[STACK_SIZE] = { ' ' };
    int powerTop = -1;

    int moves = 16;
    int score = 0;

    int topIndex = 0;

    while (topIndex < MAX_SIZE && moves > 0) {
        displayList(elements, MAX_SIZE, topIndex);
        displayStack(redStack, redTop, "Red");
        displayStack(greenStack, greenTop, "Green");
        displayStack(blueStack, blueTop, "Blue");

        if (chosenLevel == 2) {
            displayStack(powerStack, powerTop, "Power");
        }

        cout << "\nRemaining Moves: " << moves << endl;
        cout << "Current Score: " << score << endl;

        char colorToSort = getColorToSort(elements, topIndex);
        cout << "Color to Sort: " << colorToSort << endl;

        cout << "\n0+*o. Enter the stack name (R, G, B): ";
        char stackName;
        cin >> stackName;

        switch (stackName) {
            case 'R':
                if (colorToSort == 'R') {
                    if (redTop < STACK_SIZE - 1) {
                        push(redStack, redTop, colorToSort);
                    } else {
                        handleFullStack(colorToSort, powerStack, powerTop, score, chosenLevel);
                    }
                } else {
                    cout << "\nInvalid move!" << endl;
                }
                break;
            case 'G':
                if (colorToSort == 'G') {
                    if (greenTop < STACK_SIZE - 1) {
                        push(greenStack, greenTop, colorToSort);
                    } else {
                        handleFullStack(colorToSort, powerStack, powerTop, score, chosenLevel);
                    }
                } else {
                    cout << "\nInvalid move! " << endl;
                }
                break;
            case 'B':
                if (colorToSort == 'B') {
                    if (blueTop < STACK_SIZE - 1) {
                        push(blueStack, blueTop, colorToSort);
                    } else {
                        handleFullStack(colorToSort, powerStack, powerTop, score, chosenLevel);
                    }
                } else {
                    cout << "\nInvalid move!" << endl;
                }
                break;
            default:
                cout << "Invalid stack name!" << endl;
                continue;
        }

        topIndex++;
        moves--;
        score += 10;
        if (isGameWon(redStack, greenStack, blueStack, chosenLevel)) {
            
            cout << ".+*\n0.+Congratulations! You have sorted all elements correctly..+*0.+" << endl;
            break;
        }
    }
    cout << "\n.+*0.+Final Score: " << score << endl;

    if (topIndex == MAX_SIZE) {
        cout << "\n.+*0.+----LEVEL COMPLETED---*0.+" << endl;
    }
}




void QUEUEinitializeElements(char elements[], unsigned int seed) {
    srand(seed);
    for (int i = 0; i < MAX_SIZE; ++i) {
        char colors[] = {'G', 'Y', 'R'};
        elements[i] = colors[rand() % 3];
    }
}

void enqueue(char queue[], int& rear, char color) {
    if (rear < MAX_SIZE - 1) {
        queue[++rear] = color;
    } else {
        cout << "\n-----Queue is full-----" << endl;
    }
}

char dequeue(char queue[], int& front, int& rear) {
    if (front <= rear) {
        char dequeued = queue[front++]; 
        return dequeued;
    } else {
        cout << "\n-----Queue is empty-----" << endl;
        return '\0';
    }
}

void QUEUEdisplayList(const char elements[], int topIndex) {
    cout << "\nList of elements to sort: ";
    for (int i = 0; i < MAX_SIZE; ++i) {
        if (i == topIndex) {
            cout << "(" << elements[i] << ") ";
        } else {
            cout << elements[i] << " ";
        }
    }
    cout << endl;
}

void displayQueue(const char queue[], int front, int rear, const char* queueName) {
    cout << queueName << " QUEUE: ";
    if (front == -1 || front > rear) {
        cout << "EMPTY";
    } else {
        for (int i = front; i <= rear; ++i) {
            cout << queue[i] << " ";
        }
    }
    cout << endl;
}

bool QUEUEisGameWon(const char queue[], int front, int rear) {
    bool isQueueSorted = true;

    for (int i = front; i <= rear; ++i) {
        if (queue[i] > queue[i + 1]) {
            isQueueSorted = false;
            break;
        }
    }

    return isQueueSorted && (rear == MAX_SIZE - 1);
}

void QUEUEplayGame() {
    unsigned int seed = generateRandomSeed();
    char elements[MAX_SIZE];
    QUEUEinitializeElements(elements, seed);

    char redQueue[MAX_SIZE], greenQueue[MAX_SIZE], yellowQueue[MAX_SIZE];
    int redFront = -1, redRear = -1;
    int greenFront = -1, greenRear = -1;
    int yellowFront = -1, yellowRear = -1;

    int moves = 16;
    int score = 0;
    int topIndex = MAX_SIZE - 1;

    while (topIndex >= 0 && moves > 0) {
        QUEUEdisplayList(elements, topIndex); 
        displayQueue(redQueue, redFront, redRear, "RED");
        displayQueue(greenQueue, greenFront, greenRear, "GREEN");
        displayQueue(yellowQueue, yellowFront, yellowRear, "YELLOW");

        cout << "\nREMAINING MOVES: " << moves << endl;
        cout << "SCORE: " << score << endl;

        char colorToSort = elements[topIndex];
        cout << "COLOR TO SORT: " << colorToSort << endl;

        string queueName;
        cout << "\nENTER THE QUEUE NAME (RED, GREEN, YELLOW): ";
        cin >> queueName;

        if (queueName == "RED") {
            if (colorToSort == 'R') {
                if (redFront == -1) redFront = 0;
                enqueue(redQueue, redRear, colorToSort);
            } else {
                score -= 2;
                cout << "\nInvalid move! -2 points." << endl;
            }
        } else if (queueName == "GREEN") {
            if (colorToSort == 'G') {
                if (greenFront == -1) greenFront = 0;
                enqueue(greenQueue, greenRear, colorToSort);
            } else {
                score -= 2;
                cout << "\nInvalid move! -2 points." << endl;
            }
        } else if (queueName == "YELLOW") {
            if (colorToSort == 'Y') {
                if (yellowFront == -1) yellowFront = 0;
                enqueue(yellowQueue, yellowRear, colorToSort);
            } else {
                score -= 2;
                cout << "\nInvalid move! -2 points." << endl;
            }
        } else {
            cout << "Invalid queue name. Try again." << endl;
            continue;
        }

        topIndex--;
        moves--;
        score += 10;

        if (QUEUEisGameWon(redQueue, redFront, redRear) ||
            QUEUEisGameWon(greenQueue, greenFront, greenRear) ||
            QUEUEisGameWon(yellowQueue, yellowFront, yellowRear)) {
            cout << "-<+*o--Congratulations! You have sorted all elements correctly.--+*o>" << endl;
            break;
        }
    }
    cout << "\n.+*0.+Final Score: " << score << endl;

    if (topIndex < 0 || moves == 0) {
        cout << "\n<+---Level three completed!.---+>" << endl;
    }
}

int main() {
    srand(static_cast<unsigned int>(time(nullptr)));
    cout << "\n.+*0.+------------Welcome to the Color Sorting Game------------.+*0.+" << endl;

    char playAgain;
    do {
        int chosenLevel;
        cout << "PRESS 1 FOR LEVEL 1." << endl;
        cout << "PRESS 2 FOR LEVEL 2." << endl;
        cout << "PRESS 3 FOR LEVEL 3." << endl;
        cin >> chosenLevel;

        if (chosenLevel == 1 || chosenLevel == 2) {
            displayInstructions(chosenLevel);
            playGame(chosenLevel);
        } else if (chosenLevel == 3) {
            displayInstructions(chosenLevel);
            QUEUEplayGame();
        } else {
            cout << "Invalid level choice! Please choose 1, 2, or 3." << endl;
        }

        cout << "\n.+*0.+Do you want to play again? (y/n).+*0.+ : ";
        cin >> playAgain;
    } while (playAgain == 'y' || playAgain == 'Y');

    cout << "\n\t\t\t.+*0.+----Thanks for playing! Goodbye.----.+*0.+" << endl;

    return 0;
}